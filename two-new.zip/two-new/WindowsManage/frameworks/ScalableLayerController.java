package com.android.server.wm;

import android.content.pm.ApplicationInfo;
import android.content.Context;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.os.FileObserver;
import android.os.Handler;
import android.text.format.DateUtils;
import android.util.Slog;
import android.view.Display;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.Runnable;
import java.util.ArrayList;

/**
 * For feature: Video Player scaling
 */
class ScalableLayerController {
    private static final String TAG = "ScalableLayerController";

    private static final String PATH_SCALABLE_LAYER_CONFIG = "data/system/scalable_layers.xml";

    private static final String[] VIP_LAYERS = new String[] {
        // "SurfaceView - com.google.android.youtube/com.google.android.apps.youtube.app.WatchWhileActivity",
    };

    private static final long CONFIG_UPDATE_INTERVAL = 1 * DateUtils.DAY_IN_MILLIS;

    private final ArrayList<String> mScalableLayers = new ArrayList<String>();

    private Handler mHandler;
    private Runnable mLoadingTask = new Runnable() {
        @Override
        public void run() {
            loadScalableLayers();

            mHandler.postDelayed(this, CONFIG_UPDATE_INTERVAL);
        }
    };

    private long mLastModifiedTime = 0L;
    private float mScreenAspectRatio = ApplicationInfo.MAX_ASPECT_DEFAULT;

    ScalableLayerController(Context context, Handler handler) {
        mHandler = handler;

        DisplayManager dm = (DisplayManager) context.getSystemService(Context.DISPLAY_SERVICE);
        Display display = dm.getDisplay(Display.DEFAULT_DISPLAY);
        Point size = new Point();
        display.getRealSize(size);
        mScreenAspectRatio = Math.max(size.x, size.y) / (float) Math.min(size.x, size.y);

        mHandler.post(mLoadingTask);
    }

    boolean isScalableLayer(CharSequence layerTag) {
        if (mScreenAspectRatio <= ApplicationInfo.MAX_ASPECT_DEFAULT) {
            return false;
        }

        for (String vipLayer : VIP_LAYERS) {
            if (vipLayer.equals(layerTag)) {
                return true;
            }
        }

        synchronized(mScalableLayers) {
            return mScalableLayers.contains(layerTag);
        }
    }

    private void loadScalableLayers() {
        ArrayList<String> scalableLayers = null;
        File scalableLayerConfig = new File(PATH_SCALABLE_LAYER_CONFIG);
        long lastModifiedTime = 0L;
        if (scalableLayerConfig.exists()) {
            int vipSize = VIP_LAYERS.length;
            for (int i = 0 ; i < vipSize ; i++) {
                VIP_LAYERS[i] = "";
            }
            scalableLayers = parsingFile(scalableLayerConfig);
            lastModifiedTime = scalableLayerConfig.lastModified();
        }

        if (mLastModifiedTime == lastModifiedTime) {
            return;
        }

        synchronized(mScalableLayers) {
            mScalableLayers.clear();
            if (scalableLayers != null) {
                mScalableLayers.addAll(scalableLayers);
            }
        }

        mLastModifiedTime = lastModifiedTime;
    }

    private ArrayList<String> parsingFile(File config) {
        ArrayList<String> scalableLayers = new ArrayList<String>();

        try {
            InputStream fis = new FileInputStream(config);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);

            String line;
            while ((line = br.readLine()) != null) {
                line.trim();
                scalableLayers.add(line);
            }
            br.close();
            isr.close();
            fis.close();
        }
        catch (Exception e) {
            Slog.w(TAG, "Parse " + config.getName() + " failed, err: " + e.getMessage());
        }

        return scalableLayers;
    }
}
